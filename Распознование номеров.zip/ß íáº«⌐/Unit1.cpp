//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "svm.h"

#include "cv.h"
#include "cxcore.h"
#include "highgui.h"

#include <algorithm>
#include <iostream>

#include <math.h>
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sButton"
#pragma link "sGroupBox"
#pragma link "sMemo"
#pragma link "sLabel"
#pragma link "sEdit"
#pragma resource "*.dfm"
#include <string>

#define Malloc(type,n) (type *)malloc((n)*sizeof(type))

using namespace std;

string strs ="C:/digits/" ;
string l="/";
string papka;
string nomer;
string bmp= ".bmp";

string stroka;

struct svm_parameter param;     // set by parse_command_line
struct svm_problem prob;        // set by read_problem

struct svm_node *x_space;

char *im;


TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::sButton1Click(TObject *Sender)
{

     IplImage *image = 0;

     image = cvLoadImage( im, 1 );
     cvNamedWindow( "result2", 1 );
     cvNamedWindow( "result1", 1 );

     cvNamedWindow( "ROI", 1 );
     CvMemStorage* storage1 = cvCreateMemStorage(0);
     CvSeq* contours = 0;
     IplImage *image1 = cvCreateImage( cvSize(image->width,image->height), IPL_DEPTH_8U,1 );
     CvArr* src;
     CvArr*src2;

     IplImage *image3 = cvCloneImage( image );
     cvCopy(image,image3);

     cvCvtColor( image, image1, CV_BGR2GRAY );
     cvEqualizeHist( image1,  image1);
     cvSmooth( image1,image1,CV_GAUSSIAN);


     cvThreshold(image1, image1, TrackBar1->Position, TrackBar2->Position, CV_ADAPTIVE_THRESH_MEAN_C);
     //cvCanny(image1,image1,140,255);
     
     


     cvFindContours( image1, storage1, &contours, sizeof(CvContour),CV_RETR_EXTERNAL ,CV_CHAIN_APPROX_SIMPLE, cvPoint(0,0) );
     CvRect rect;
     float maxContur=0;

      for (; contours != 0; contours = contours->h_next)
      {
          if(cvContourPerimeter(contours)>maxContur){
               maxContur=(float) cvContourPerimeter(contours);
                                                     }

      }

     cvFindContours( image1, storage1, &contours, sizeof(CvContour),CV_RETR_EXTERNAL ,CV_CHAIN_APPROX_SIMPLE, cvPoint(0,0) );


     for (; contours != 0; contours = contours->h_next)
      {
       if((int)cvContourPerimeter(contours)==(int)maxContur ){
         //�������� ��������� ����� ������
          rect= cvBoundingRect(contours);
          //cvRectangle(image3,cvPoint(rect.x, rect.y),cvPoint(rect.x+rect.width, rect.y+rect.height),cvScalar(0, 0, 255),2, 8, 0);
          cvSetImageROI(image, cvRect(rect.x,rect.y,rect.width,rect.height));
          //�������� ������� ����� � �����

          IplImage *img = cvCreateImage( cvSize(rect.width,rect.height), IPL_DEPTH_8U,1);
           cvCvtColor( image, img, CV_BGR2GRAY );
          //cvCopy(image1,img);
          IplImage *img2 =  cvCloneImage( img );
          cvResetImageROI(image);
          cvEqualizeHist( img2,  img2);
           
           //cvSmooth( img2,img2,CV_GAUSSIAN);


           sMemo1->Lines->Add("�������");
           sMemo1->Lines->Clear();
           cvThreshold(img2, img2, 100, 255, CV_THRESH_BINARY_INV);

           CvSeq* contours1 = 0;
    
           cvCanny(img2,img2,200,250);
           cvFindContours( img2, storage1, &contours1, sizeof(CvContour),CV_RETR_EXTERNAL ,CV_CHAIN_APPROX_SIMPLE, cvPoint(0,0) );
           CvRect rect2;
           float k=0;
           for (; contours1 != 0; contours1 = contours1->h_next){
               if(-1*(int)cvContourArea(contours1)>0 ){
                   if( (int)cvContourPerimeter(contours1)<400){

               rect2= cvBoundingRect(contours1);
                IplImage *imageReconition = cvCreateImage( cvSize(rect2.width,rect2.height), IPL_DEPTH_8U,1);


               k = sqrt(pow(rect2.width, 2)+ pow(rect2.height,2)) ;
              if(k >19 && k<55 ){
                     if(rect2.width>10&& rect2.height>10){
                       // if( rect2.width<rect2.height)
             //Rectangle(img,cvPoint(rect2.x, rect2.y),cvPoint(rect2.x+rect2.width, rect2.y+rect2.height),cvScalar(255, 0, 0),0, 1, 0);
            //sMemo1->Lines->Add(img->depth);

            cvSetImageROI(img, cvRect(rect2.x,rect2.y,rect2.width,rect2.height));

            cvCopy(img, imageReconition);
            cvEqualizeHist( imageReconition,  imageReconition);
            cvResetImageROI(img);
            IplImage * scaled;
            scaled = cvCreateImage( cvSize(20, 20), imageReconition->depth, imageReconition->nChannels );
            cvResize(imageReconition, scaled, CV_INTER_LINEAR);
            cvEqualizeHist( scaled,  scaled);
            cvThreshold(scaled,scaled, 100, 255, CV_THRESH_BINARY );
            double vectorImage[400];
            CvMat stub, *dst_mat;
            dst_mat = cvGetMat(scaled, &stub, 0, 0);
            int numbers =0;
            for(int a=0; a<dst_mat->rows; a++){
                 for(int b=0; b<dst_mat->cols; b++){
                     vectorImage[numbers]= cvGet2D(dst_mat, a, b).val[0];
                           //sMemo1->Lines->Add(vectorImage[0]);
                            numbers++;
                }
             }


             svm_node* testnode = Malloc(svm_node,400);

             for (int col = 0;col <400;col++){
                testnode[col].index = col+1;
                testnode[col].value =  vectorImage[col];
                                             }
                   testnode[399].index = -1;
             string name_catalog =ExtractFilePath(Application->ExeName).c_str();
             
             for (int t=0;t< name_catalog.length();t++)
                           {
               if (name_catalog[t]== '\\')
                    name_catalog[t]=*"/";

                        }



             string name_file ="MyModel";
             //ShowMessage((name_catalog+name_file).c_str());

             struct  svm_model *model = svm_load_model((name_catalog+name_file).c_str()) ;
              sMemo1->Lines->Add("������������ ->");
            sMemo1->Lines->Add(svm_predict(model,testnode));

            cvShowImage( "ROI", scaled);
            cvWaitKey(0);
            free(testnode);
            //svm_destroy_param(&param);
             }}}}



                }
        cvShowImage( "ROI", img);
         cvWaitKey(0);

        }


      }

      cvShowImage( "result1", image3 );
      cvShowImage( "result2", image );

     cvReleaseImage( &image );
     cvReleaseImage( &image1 );
     cvReleaseMemStorage( &storage1 );
     cvWaitKey(0);
     cvDestroyAllWindows();//�������� ����

}
//---------------------------------------------------------------------------
void __fastcall TForm1::sButton2Click(TObject *Sender)
{
  //ShowMessage(GetCurrentDir());

  OpenDialog1->Execute();
  im = OpenDialog1->FileName.c_str();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TrackBar1Change(TObject *Sender)
{
Label1->Caption= TrackBar1->Position;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TrackBar2Change(TObject *Sender)
{
 Label2->Caption= TrackBar2->Position;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::sButton3Click(TObject *Sender)

{   sMemo1->Lines->Add(im);
   svm_node* node = Malloc(svm_node,400);
   string name_catalog =ExtractFilePath(Application->ExeName).c_str();
             
   for (int t=0;t< name_catalog.length();t++)
   {
   if (name_catalog[t]== '\\')
      name_catalog[t]=*"/";
          }

    string name_file ="MyModel";

   //--------------------------------------------------------


   struct  svm_model *model = svm_load_model((name_catalog+name_file).c_str()) ;
   IplImage *image1 = 0;
   image1 = cvLoadImage( im, 0 );
   cvNamedWindow( "result2", 1 );
   //IplImage *image = cvCreateImage( cvSize(image1->width,image1->height), IPL_DEPTH_8U,1 );
   //cvCvtColor( image1, image, CV_BGR2GRAY );

   IplImage * scaled;
   scaled = cvCreateImage( cvSize(20, 20), image1->depth, image1->nChannels );
   cvResize(image1, scaled, CV_INTER_LINEAR);
   cvThreshold(scaled, scaled, 100, 255, CV_THRESH_BINARY);
   double vectorImage[400];
   CvMat stub, *dst_mat;
   dst_mat = cvGetMat(scaled, &stub, 0, 0);
   int numbers =0;
   for(int a=0; a<dst_mat->rows; a++){
       for(int b=0; b<dst_mat->cols; b++){
           vectorImage[numbers]= cvGet2D(dst_mat, a, b).val[0];
           numbers++;
                }
             }
   for (int col = 0;col <400;col++){
       node[col].index = col+1;
       node[col].value =  vectorImage[col];
                                    }
       node[399].index = -1;




   //sMemo1->Lines->Add(model->param.gamma);

   sMemo1->Lines->Add("������������ ->");
   sMemo1->Lines->Add(svm_predict(model,node));

   cvShowImage( "result2", scaled);
   cvWaitKey(0);
   cvDestroyAllWindows();
   free(node);

}
//---------------------------------------------------------------------------



