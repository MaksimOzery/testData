//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sButton.hpp"
#include "sGroupBox.hpp"
#include "sMemo.hpp"
#include <Dialogs.hpp>
#include <ComCtrls.hpp>
#include "sLabel.hpp"
#include "sEdit.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TsGroupBox *sGroupBox1;
        TsButton *sButton1;
        TsButton *sButton2;
        TsGroupBox *sGroupBox2;
        TsMemo *sMemo1;
        TOpenDialog *OpenDialog1;
        TTrackBar *TrackBar1;
        TTrackBar *TrackBar2;
        TLabel *Label1;
        TLabel *Label2;
        TsButton *sButton3;
        TsEdit *sEdit1;
        void __fastcall sButton1Click(TObject *Sender);
        void __fastcall sButton2Click(TObject *Sender);
        void __fastcall TrackBar1Change(TObject *Sender);
        void __fastcall TrackBar2Change(TObject *Sender);
        void __fastcall sButton3Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
