//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "svm.h"
#include "cv.h"

#include "ml.h"

#include <fstream>
#include <conio.h>

#include <string>
#include "highgui.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sButton"
#pragma link "sMemo"
#pragma link "sEdit"
#pragma resource "*.dfm"

#define Malloc(type,n) (type *)malloc((n)*sizeof(type))

#include "fann.h"
#include "floatfann.h"

struct svm_parameter param;     // set by parse_command_line
struct svm_problem prob;        // set by read_problem
//struct svm_model *model;
struct svm_node *x_space;

TForm1 *Form1;

using namespace std;

string strs ="C:/digits/" ;
string l="/";
string papka;
string nomer;
string bmp= ".bmp";




//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::sButton1Click(TObject *Sender)
{

const char *error_msg;

param.svm_type = NU_SVC;
param.kernel_type = LINEAR;
param.degree = 3;
param.gamma = 0.5;
param.coef0 = 0;
param.nu = 0.5;
param.cache_size = 100;
param.C = 1;
param.eps = 1e-3;
param.p = 0.1;
param.shrinking = 1;
param.probability = 0;
param.nr_weight = 0;
param.weight_label = NULL;
param.weight = NULL;




IplImage* img[1000];

IplImage * scaled;
CvMat image_mat ;

prob.l = 1000;
svm_node** x = Malloc(svm_node*,prob.l);

//ifstream out("myfile.txt");

double vectorImage[400];
int samples[1000];
int k=0;
int s=0;

for(int i=0;i<=9; i++){
  for(int j=1;j<=100; j++){
  papka=IntToStr(i).c_str();
  nomer=IntToStr(j).c_str();
  img[k] = cvLoadImage(( strs+papka+l+nomer+bmp).c_str() , 0);
  //Memo1->Text= IntToStr(img->size()).c_str();
  samples[k]=i;
  k++;
  scaled = cvCreateImage( cvSize(20, 20), img[k-1]->depth, img[k-1]->nChannels );
  cvResize(img[k-1], scaled, CV_INTER_LINEAR);
  cvThreshold(scaled,scaled, 100, 255, CV_THRESH_BINARY );
  // ���������� ������ ��� �������
  CvMat stub, *dst_mat;
  dst_mat = cvGetMat(scaled, &stub, 0, 0);
  int numbers =0;
  for(int a=0; a<dst_mat->rows; a++){
          for(int b=0; b<dst_mat->cols; b++){
                     vectorImage[numbers]= cvGet2D(dst_mat, a, b).val[0];
                          //  sMemo1->Lines->Add(vectorImage[0]);
                            numbers++;
                }
        }

   svm_node* x_space = Malloc(svm_node,400);
   for (int col = 0;col <400;col++){
       x_space[col].index = col+1;
       x_space[col].value =  vectorImage[col];
        }
   x_space[399].index = -1;      //Each row of properties should be terminated with a -1 according to the readme
   x[s] = x_space;
   s++;




    //cvNamedWindow("Example1", CV_WINDOW_AUTOSIZE );//�������� ����
   // cvShowImage("Example1", dst_mat);//����� ����������� � ����
   // cvWaitKey(0);//�������� ������� ����� �������
   // cvDestroyWindow("Example1");//�������� ����
   //  break;


  }

}
sMemo1->Lines->Add("��������...");
prob.x = x;
prob.y = Malloc(double,prob.l);
for(int i= 0; i<1000;i++){
  prob.y[i]=  samples[i];

}

struct svm_model *model = svm_train(&prob,&param);





   svm_node* testnode = Malloc(svm_node,400);

   int samples2[100];
   IplImage* img2;
    k=0;
  string nomerPapki=sEdit1->Text.c_str();
  string test1="C:/digits/";
  string test2= "/1.bmp";
  sMemo1->Lines->Add("������������...");
  sMemo1->Lines->Add((test1+nomerPapki+test2).c_str());
  img2 = cvLoadImage((test1+nomerPapki+test2).c_str() , 0);
  scaled = cvCreateImage( cvSize(20, 20), img2->depth, img2->nChannels );
  cvResize(img2, scaled, CV_INTER_LINEAR);
  cvThreshold(scaled,scaled, 100, 255, CV_THRESH_BINARY );
  // ���������� ������ ��� �������
  CvMat stub, *dst_mat;
  dst_mat = cvGetMat(scaled, &stub, 0, 0);
  int numbers =0;
  for(int a=0; a<dst_mat->rows; a++){
          for(int b=0; b<dst_mat->cols; b++){
                     vectorImage[numbers]= cvGet2D(dst_mat, a, b).val[0];
                            numbers++;
                }
        }


    for (int col = 0;col <400;col++){
       testnode[col].index = col+1;
       testnode[col].value =  vectorImage[col];
        }
       testnode[399].index = -1;




sMemo1->Lines->Add("������������ ->");

sMemo1->Lines->Add(svm_predict(model,testnode));
svm_destroy_param(&param);
free(prob.y);
free(prob.x);
free(x_space);

 sMemo1->Lines->Add("���������� ������...");
svm_save_model("MyModel", model);



 //Memo1->Text= IntToStr(samples[999]).c_str();
cvNamedWindow("Example1", CV_WINDOW_AUTOSIZE );//�������� ����
cvShowImage("Example1", img2);//����� ����������� � ����
cvWaitKey(0);//�������� ������� ����� �������
cvDestroyWindow("Example1");//�������� ����




  




}
//---------------------------------------------------------------------------




void __fastcall TForm1::sButton2Click(TObject *Sender)
{
double vectorImage[400];
IplImage * scaled;
  svm_node* testnode = Malloc(svm_node,400);
  struct  svm_model *model2 = svm_load_model("C://MyModel") ;
   int samples2[100];
   IplImage* img2;
   int k=0;
  string nomerPapki=sEdit1->Text.c_str();
  string test1="C:/digits/";
  string test2= "/4.bmp";
  sMemo1->Lines->Add("������������...");
  sMemo1->Lines->Add((test1+nomerPapki+test2).c_str());
  img2 = cvLoadImage((test1+nomerPapki+test2).c_str() , 0);
  scaled = cvCreateImage( cvSize(20, 20), img2->depth, img2->nChannels );
  cvResize(img2, scaled, CV_INTER_LINEAR);
  cvThreshold(scaled,scaled, 100, 255, CV_THRESH_BINARY );
  // ���������� ������ ��� �������
  CvMat stub, *dst_mat;
  dst_mat = cvGetMat(scaled, &stub, 0, 0);
  int numbers =0;
  for(int a=0; a<dst_mat->rows; a++){
          for(int b=0; b<dst_mat->cols; b++){
                     vectorImage[numbers]= cvGet2D(dst_mat, a, b).val[0];
                            numbers++;
                }
        }


    for (int col = 0;col <400;col++){
       testnode[col].index = col+1;
       testnode[col].value =  vectorImage[col];
        }
       testnode[399].index = -1;




sMemo1->Lines->Add("������������ ->");

sMemo1->Lines->Add(svm_predict(model2,testnode));
svm_destroy_param(&param);
free(prob.y);
free(prob.x);
free(x_space);
}
//---------------------------------------------------------------------------

